#![allow(unused)]

mod abigen;
pub(crate) mod common;
#[cfg(feature = "abigen")]
mod console;
#[cfg(feature = "abigen")]
mod contract;

fn main() {}
