# ethers-wasm

## Example

Install wasm-pack with

    yarn install

Start a local Anvil or Ganache instance

    yarn anvil
    or
    yarn ganache

Build the example locally with:

    yarn serve

Visit http://localhost:8080 in a browser to run the example!
